import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomepgComponent } from './homepg/homepg.component';
import { AboutusComponent } from './aboutus/aboutus.component';
import { ContactusComponent } from './contactus/contactus.component';
import { CoursesComponent } from './courses/courses.component';
import { PortfolioComponent } from './portfolio/portfolio.component';
import { PricingComponent } from './pricing/pricing.component';

const routes: Routes = [{path:'',component:HomepgComponent},
{path:'about/',component:AboutusComponent},
{path:'courses/',component:CoursesComponent},
{path:'portfolio/',component:PortfolioComponent},
{path:'pricing/',component:PricingComponent},
{path:'contact/',component:ContactusComponent}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
