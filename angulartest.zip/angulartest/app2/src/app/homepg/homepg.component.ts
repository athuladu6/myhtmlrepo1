import { Component } from '@angular/core';

@Component({
  selector: 'app-homepg',
  templateUrl: './homepg.component.html',
  styleUrls: ['./homepg.component.css']
})
export class HomepgComponent {

}
